package ee.taltech.iti0202.travelagency.enums;

public enum Activity {

    WINE, DINE, SKIING, SUNBATHING, MEETING
}

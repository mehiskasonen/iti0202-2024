package ee.taltech.iti0202.travelagency.enums;

public enum ClientType {
    REGULAR, SILVER, GOLD
}

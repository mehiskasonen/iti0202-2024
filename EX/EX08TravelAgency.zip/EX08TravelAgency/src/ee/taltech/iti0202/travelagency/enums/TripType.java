package ee.taltech.iti0202.travelagency.enums;

public enum TripType {
    BEACH_HOLIDAY, SKIING, LAST_MINUTE, GOURMET, SUN_AND_SEA, CULTURE, HIKING
}

package ee.taltech.iti0202.delivery;

import ee.taltech.iti0202.delivery.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class OneLocationPickUpStrategyTest {

    @Test
    void onlyPickUpFromOneLocation() {
        World world = new World();

        Location tallinn = world.addLocation("Tallinn", new ArrayList<>(), new ArrayList<>()).get();
        Location tartu = world.addLocation("Tartu", List.of("Tallinn"), List.of(3)).get();
        Location parnu = world.addLocation("Pärnu", List.of("Tartu", "Tallinn"), List.of(4, 3)).get();

        Packet packetTallinn1 = new Packet("tal1", tartu);
        Packet packetTallinn2 = new Packet("tal2", tartu);
        Packet packetTartu1 = new Packet("tartu1", tallinn);
        Packet packetTartu2 = new Packet("tartu2", tallinn);
        tallinn.addPacket(packetTallinn1);
        tallinn.addPacket(packetTallinn2);
        tartu.addPacket(packetTartu1);
        tartu.addPacket(packetTartu2);

        Action actionMati1 = new Action(tartu);
        actionMati1.addTake("tal1");
        Action actionMati2 = new Action(tallinn);
        Strategy strategyMati = new DummyStrategy(List.of(actionMati1, actionMati2));

        Courier courier1 = world.addCourier("Mati", "Tallinn").get();
        world.giveStrategy("Mati", strategyMati);

        System.out.println(courier1); //Mati Tallinn. PACKETS:
        world.tick();

        System.out.println(courier1); // Mati (null). PACKETS: tal1

    }
}